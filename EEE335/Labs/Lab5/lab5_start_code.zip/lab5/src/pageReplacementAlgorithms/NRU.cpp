#include "NRU.h"



int NRU::findVirtualPageToEvict(TableEntry *pageTable)
{
	return 0;
}

void NRU::virtualPageEvicted(TableEntry *pageTable, int virtualPage)
{

}

void NRU::virtualPageLoaded(TableEntry *pageTable, int virtualPage)
{

}

void NRU::virtualPageAccessed(TableEntry *pageTable, int virtualPage, bool modified)
{

}
