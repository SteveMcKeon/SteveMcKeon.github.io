#include "Clock.h"



int Clock::findVirtualPageToEvict(TableEntry *pageTable)
{
	return 0;
}

void Clock::virtualPageEvicted(TableEntry *pageTable, int virtualPage)
{

}

void Clock::virtualPageLoaded(TableEntry *pageTable, int virtualPage)
{

}

void Clock::virtualPageAccessed(TableEntry *pageTable, int virtualPage, bool modified)
{

}
