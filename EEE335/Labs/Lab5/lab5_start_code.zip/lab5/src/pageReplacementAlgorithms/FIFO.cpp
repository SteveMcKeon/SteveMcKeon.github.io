#include "FIFO.h"



int FIFO::findVirtualPageToEvict(TableEntry *pageTable)
{
	return 0;
}

void FIFO::virtualPageEvicted(TableEntry *pageTable, int virtualPage)
{

}

void FIFO::virtualPageLoaded(TableEntry *pageTable, int virtualPage)
{

}

void FIFO::virtualPageAccessed(TableEntry *pageTable, int virtualPage, bool modified)
{

}
