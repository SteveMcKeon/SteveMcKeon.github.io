#include "SecondChance.h"



int SecondChance::findVirtualPageToEvict(TableEntry *pageTable)
{
	return 0;
}

void SecondChance::virtualPageEvicted(TableEntry *pageTable, int virtualPage)
{

}

void SecondChance::virtualPageLoaded(TableEntry *pageTable, int virtualPage)
{

}

void SecondChance::virtualPageAccessed(TableEntry *pageTable, int virtualPage, bool modified)
{

}
