#include "WorkingSet.h"



int WorkingSet::findVirtualPageToEvict(TableEntry *pageTable)
{
	return 0;
}

void WorkingSet::virtualPageEvicted(TableEntry *pageTable, int virtualPage)
{

}

void WorkingSet::virtualPageLoaded(TableEntry *pageTable, int virtualPage)
{

}

void WorkingSet::virtualPageAccessed(TableEntry *pageTable, int virtualPage, bool modified)
{

}
