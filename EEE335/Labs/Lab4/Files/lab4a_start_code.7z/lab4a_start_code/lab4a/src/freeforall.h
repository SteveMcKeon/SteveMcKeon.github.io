#pragma once


void *freeforall_printer(void *arg);
void *freeforall_process(void *arg);
void demo_freeforall();
