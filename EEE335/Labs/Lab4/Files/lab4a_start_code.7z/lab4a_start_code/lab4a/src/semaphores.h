#pragma once

void demo_semaphores();
