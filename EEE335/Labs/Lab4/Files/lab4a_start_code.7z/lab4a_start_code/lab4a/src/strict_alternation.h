#pragma once

void demo_strict_alternation();
