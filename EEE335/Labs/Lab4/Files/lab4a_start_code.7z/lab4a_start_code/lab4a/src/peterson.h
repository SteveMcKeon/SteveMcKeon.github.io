#pragma once

void demo_peterson();
